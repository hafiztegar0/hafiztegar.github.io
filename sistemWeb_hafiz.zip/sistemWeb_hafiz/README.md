# Aplikasi sederhana manajemen surat dengan PHP MySQLi

Aplikasi ini digunakan untuk memenuhi project UAS Pemrograman WEB
Program Studi Sistem Informasi
UNIVERSITAS MURIA KUDUS
Nama : Hafiz Tegar Aryoprakosa
NIM : 202053144
