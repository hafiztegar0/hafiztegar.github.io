<div id="content" class="main-content">
    <div class="layout-px-spacing">
        <div class="layout-spacing mt-3">
            <div class="widget-content widget-content-area br-6">
                <div class="text-center mb-3">
                    <h4>SELAMAT DATANG <b><u><?= ucfirst($_SESSION['user']['username']) ?></u></b>, DI</h4>
                    <h4><b>SISTEM INFORMASI STOK BAHAN BAKU ROTI</b></h4>
                    <img src="assets/img/home.png" alt="Home Image" class="l-image" style="width: 500px; height: auto;">
                </div>
            </div>
        </div>
    </div>
</div>